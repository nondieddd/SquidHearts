package net.minecraft.client.data;

import com.google.common.collect.ImmutableList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.state.property.Property.Value;
import net.minecraft.util.Util;

/**
 * Represents a set of property to value pairs, used as conditions for model
 * application.
 * 
 * <p>This object is immutable.
 */
@Environment(EnvType.CLIENT)
public record PropertiesMap(List<Value<?>> values) {
	public static final PropertiesMap EMPTY = new PropertiesMap(List.of());
	private static final Comparator<Value<?>> COMPARATOR = Comparator.comparing(value -> value.property().getName());

	public PropertiesMap withValue(Value<?> value) {
		return new PropertiesMap(Util.withAppended(this.values, value));
	}

	public PropertiesMap copyOf(PropertiesMap propertiesMap) {
		return new PropertiesMap(ImmutableList.<Value<?>>builder().addAll(this.values).addAll(propertiesMap.values).build());
	}

	public static PropertiesMap withValues(Value<?>... values) {
		return new PropertiesMap(List.of(values));
	}

	public String asString() {
		return (String)this.values.stream().sorted(COMPARATOR).map(Value::toString).collect(Collectors.joining(","));
	}

	public String toString() {
		return this.asString();
	}
}
