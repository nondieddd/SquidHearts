package net.minecraft.client.gui.render.state.special;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.model.ModelPart;
import net.minecraft.component.type.BannerPatternsComponent;
import net.minecraft.util.DyeColor;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public record BannerResultGuiElementRenderState(
	ModelPart flag,
	DyeColor baseColor,
	BannerPatternsComponent resultBannerPatterns,
	int x1,
	int y1,
	int x2,
	int y2,
	@Nullable ScreenRect scissorArea,
	@Nullable ScreenRect bounds
) implements SpecialGuiElementRenderState {
	public BannerResultGuiElementRenderState(
		ModelPart flag, DyeColor color, BannerPatternsComponent bannerPatterns, int x1, int y1, int x2, int y2, @Nullable ScreenRect scissorArea
	) {
		this(flag, color, bannerPatterns, x1, y1, x2, y2, scissorArea, SpecialGuiElementRenderState.createBounds(x1, y1, x2, y2, scissorArea));
	}

	@Override
	public float scale() {
		return 16.0F;
	}
}
