package com.me.nondied.squidhearts.client.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_329.class)
public abstract class InGameHudMixin {

    @Shadow
    public abstract class_327 getTextRenderer();

    @ModifyArgs(
            method = "renderStatusBars",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/hud/InGameHud;renderHealthBar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/entity/player/PlayerEntity;IIIIFIIIZ)V"
            )
    )
    private void centerHealthBar(Args args) {
        int width = class_310.method_1551().method_22683().method_4486();
        int height = class_310.method_1551().method_22683().method_4502();
        args.set(2, width / 2 - 40);
        args.set(3, height - 33);
    }

    @Inject(
            method = "renderHealthBar",
            at = @At("HEAD"),
            cancellable = true
    )
    private void hideAbsorptionBar(class_332 context, class_1657 player, int x, int y, int lines, int regeneratingHeartIndex, float maxHealth, int lastHealth, int health, int absorption, boolean renderingAbsorption, CallbackInfo ci) {
        if (renderingAbsorption) {
            ci.cancel();
        }
    }

    @Inject(method = "renderFood", at = @At("HEAD"), cancellable = true, require = 0)
    private void hideFoodBar(class_332 context, class_1657 player, int top, int right, CallbackInfo ci) {
        ci.cancel();
    }

    @Redirect(
            method = "renderStatusBars",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V"
            )
    )
    private void modifyStatusSprites(class_332 instance, class_2960 texture, int x, int y, int width, int height) {
        String path = texture.method_12832();
        if (path.contains("food") || path.contains("hunger") || path.contains("beef") || path.contains("meat")) {
            return;
        }
        if (path.contains("absorption")) {
            return;
        }
        if (path.contains("heart/container")) {
            instance.method_52706(class_2960.method_60655("minecraft", "hud/heart/0"), x, y, width, height);
            return;
        }
        if (path.contains("bubble")) {
            instance.method_52706(texture, x, y - 10, width, height);
            return;
        }
        instance.method_52706(texture, x, y, width, height);
    }

    @Inject(method = "renderExperienceBar", at = @At("HEAD"), cancellable = true)
    private void hideExpBar(class_332 context, int x, CallbackInfo ci) {
        ci.cancel();
    }

    @Inject(method = "renderExperienceLevel", at = @At("HEAD"), cancellable = true)
    private void centerExpLevel(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        ci.cancel();

        class_310 client = class_310.method_1551();
        int level = 0;
        if (com.me.nondied.squidhearts.client.SquidHeartsClientState.visualExperience != -1) {
            level = com.me.nondied.squidhearts.client.SquidHeartsClientState.visualExperience;
        } else if (client.field_1724 != null) {
            level = client.field_1724.field_7520;
        }

        if (level > 0) {
            client.method_16011().method_15396("expLevel");

            String levelString = String.valueOf(level);
            int screenWidth = context.method_51421();
            int screenHeight = context.method_51443();

            int textX = (screenWidth - this.getTextRenderer().method_1727(levelString)) / 2;
            int textY = screenHeight - 43;

            context.method_51433(this.getTextRenderer(), levelString, textX + 1, textY, 0x000000, false);
            context.method_51433(this.getTextRenderer(), levelString, textX - 1, textY, 0x000000, false);
            context.method_51433(this.getTextRenderer(), levelString, textX, textY + 1, 0x000000, false);
            context.method_51433(this.getTextRenderer(), levelString, textX, textY - 1, 0x000000, false);
            context.method_51433(this.getTextRenderer(), levelString, textX, textY, 0xFFFFFF, false);

            client.method_16011().method_15407();
        }
    }

    @Redirect(
            method = "renderHotbar",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lnet/minecraft/util/Identifier;IIII)V"
            )
    )
    private void fixHotbarSelectionOffset(class_332 instance, class_2960 texture, int x, int y, int width, int height) {
        if (texture.method_12832().contains("hotbar_selection")) {
            instance.method_52706(texture, x - 1, y, width, height);
        } else {
            instance.method_52706(texture, x, y, width, height);
        }
    }
}